<?php
/*
Plugin Name: Awesome Plugin
Description: Adds a custom post type called 'Awesome' to WordPress.
Version: 1.0
Text Domain: awesome-plugin
Author: Luqman Ud Din
*/

// Include files
require_once  plugin_dir_path( __FILE__ ) . 'includes/class-awesome-plugin.php';
require_once  plugin_dir_path( __FILE__ ) . 'includes/activate.php';
require_once  plugin_dir_path( __FILE__ ) . 'includes/deactivate.php';