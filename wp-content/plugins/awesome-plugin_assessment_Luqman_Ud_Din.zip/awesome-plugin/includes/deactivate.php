<?php 

/**
 * this file will handle deactivation
 */

function deactivate_awesome_plugin() {
    $plugin = new Awesome_Plugin();
    $plugin->deactivate();
}
register_deactivation_hook( plugin_dir_path( __FILE__ ), 'deactivate_awesome_plugin');