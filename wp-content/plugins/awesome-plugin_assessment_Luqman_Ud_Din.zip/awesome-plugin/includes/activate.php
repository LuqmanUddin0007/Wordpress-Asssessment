<?php

/**
 * this file will handle activation
 */

function activate_awesome_plugin() {
    $plugin = new Awesome_Plugin();
    $plugin->activate();
}
register_activation_hook( plugin_dir_path( __FILE__ ), 'activate_awesome_plugin');