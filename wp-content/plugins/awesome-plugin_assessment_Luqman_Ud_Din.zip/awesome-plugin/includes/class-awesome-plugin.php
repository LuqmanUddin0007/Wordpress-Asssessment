<?php 

/**
 * this class will handle the registration of custom post type "Awesome"
 */

class Awesome_Plugin {
    public function __construct() {
        add_action( 'init', array( $this, 'register_custom_post_type' ) );
        register_activation_hook( plugin_dir_path( __FILE__ ) . 'includes/' , array( $this, 'activate' ) );
        register_deactivation_hook( plugin_dir_path( __FILE__ ) . 'includes/' , array( $this, 'deactivate' ) );
    }

    public function register_custom_post_type() {
        $labels = array(
            'name'                  => _x( 'Awesome', 'post type general name', 'wordpressassessment' ),
            'singular_name'         => _x( 'Awesome', 'post type singular name', 'wordpressassessment' ),
            'menu_name'             => _x( 'Awesome', 'admin menu', 'wordpressassessment' ),
            'name_admin_bar'        => _x( 'Awesome', 'add new on admin bar', 'wordpressassessment' ),
            'add_new'               => _x( 'Add New', 'Awesome', 'wordpressassessment' ),
            'add_new_item'          => __( 'Add New Awesome', 'wordpressassessment' ),
            'new_item'              => __( 'New Awesome', 'wordpressassessment' ),
            'edit_item'             => __( 'Edit Awesome', 'wordpressassessment' ),
            'view_item'             => __( 'View Awesome', 'wordpressassessment' ),
            'all_items'             => __( 'All Awesome', 'wordpressassessment' ),
            'search_items'          => __( 'Search Awesome', 'wordpressassessment' ),
            'parent_item_colon'     => __( 'Parent Awesome:', 'wordpressassessment' ),
            'not_found'             => __( 'No Awesome found.', 'wordpressassessment' ),
            'not_found_in_trash'    => __( 'No Awesome found in Trash.', 'wordpressassessment' ),
            'featured_image'        => _x( 'Featured Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'wordpressassessment' ),
            'set_featured_image'    => _x( 'Set featured image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'wordpressassessment' ),
            'remove_featured_image' => _x( 'Remove featured image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'wordpressassessment' ),
            'use_featured_image'    => _x( 'Use as featured image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'wordpressassessment' ),
            'archives'              => _x( 'Awesome Archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'wordpressassessment' ),
            'insert_into_item'      => _x( 'Insert into awesome', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'wordpressassessment' ),
            'uploaded_to_this_item' => _x( 'Uploaded to this awesome', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'wordpressassessment' ),
            'filter_items_list'     => _x( 'Filter awesome list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'wordpressassessment' ),
            'items_list_navigation' => _x( 'Awesome list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'wordpressassessment' ),
            'items_list'            => _x( 'Awesome list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'wordpressassessment' ),
        );

        $args = array(
            'labels'                => $labels,
            'description'           => __( 'Description.', 'wordpressassessment' ),
            'public'                => true,
            'publicly_queryable'    => true,
            'show_ui'               => true,
            'show_in_menu'          => true,
            'query_var'             => true,
            'rewrite'               => array( 'slug' => 'awesome' ),
            'capability_type'       => 'post',
            'has_archive'           => true,
            'hierarchical'          => false,
            'menu_position'         => null,
            'supports'              => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' ),
            'taxonomies'            => array( 'category', 'post_tag' ), // Example taxonomies
            'show_in_rest'          => true, // Enable Gutenberg editor
            'rest_base'             => 'awesome-api', // Base URL for the REST API endpoint
            'rest_controller_class' => 'WP_REST_Posts_Controller', // REST API controller class
            'menu_icon'             => 'dashicons-admin-post', // Icon for the menu
        );

        register_post_type( 'awesome', $args );
    }

    public function activate() {
        flush_rewrite_rules();
    }

    public function deactivate() {
        unregister_post_type( 'awesome' );
        flush_rewrite_rules();
    }
}

new Awesome_Plugin();